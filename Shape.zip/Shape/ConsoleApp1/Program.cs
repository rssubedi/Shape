﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Shape
    {
        static void Main(string[] args)
        {
            double Width = 0;
            double Height = 0;
            double Radius = 0;
            double LengthOfSide = 0;
            double SemiMajorAxis = 0;
            double SemiMinorAxis = 0;

        UserChoice:
            Console.WriteLine("For what shape would you like to calculated the area:\n1. Square\n2. Rectangle\n3. Circle\n4. Ellipse");
            Console.Write("Please Enter the number from above: ");
            int choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    Console.Write("Please enter the side of square:");
                    LengthOfSide = double.Parse(Console.ReadLine());
                    break;
                case 2:
                    Console.Write("Please enter the Height of rectangle: ");
                    Height = double.Parse(Console.ReadLine());
                    Console.Write("Please enter the width of rectangle: ");
                    Width = double.Parse(Console.ReadLine());
                    break;
                case 3:
                    Console.Write("Please enter the radius of circle: ");
                    Radius = double.Parse(Console.ReadLine());
                    break;
                case 4:
                    Console.Write("Please enter the SemiMajorAxis of Ellipse: ");
                    SemiMajorAxis = double.Parse(Console.ReadLine());
                    Console.Write("Please enter the SemiMinorAxis of Ellipse: ");
                    SemiMinorAxis = double.Parse(Console.ReadLine());
                    break;
                default:
                    Console.WriteLine("Incorrect hoice, please try again with another choice!");
                    goto UserChoice;

            }
            CalculatePerimeter Sqa = new Squar();
            CalculatePerimeter Rec = new Rectangl();
            CalculatePerimeter Cir = new Circl();
            CalculatePerimeter Ell = new Ellips();

            CalculateArea Sqau = new Square();
            CalculateArea Rect = new Rectangle();
            CalculateArea Circ = new Circle();
            CalculateArea Elli = new Ellipse();
            if (choice == 1)
            {
                Sqau.Area(LengthOfSide);
                Sqau.ShowResult();
            }
            else if (choice == 2)
            {
                Rect.Area(Height, Width);
                Rect.ShowResult();
            }
            else if (choice == 3)
            {
                Circ.Area(Radius);
                Circ.ShowResult();
            }
            else
            {
                Elli.Area(SemiMajorAxis, SemiMinorAxis);
                Elli.ShowResult();
            }
            if (choice == 1)
            {
                Sqa.Perimeter(LengthOfSide);
                Sqa.ShowResult();
            }
            else if (choice == 2)
            {
                Rec.Perimeter(Height, Width);
                Rec.ShowResult();
            }
            else if (choice == 3)
            {
                Cir.Perimeter(Radius);
                Cir.ShowResult();
            }
            else
            {
                Ell.Perimeter(SemiMajorAxis, SemiMinorAxis);
                Ell.ShowResult();
            }

        AnotherCalculation:
            Console.Write("\nDo you want to calculate area and Perimeter of any other shape? Give input in Yes or NO: ");
            string choice1 = Console.ReadLine();
            switch (choice1.ToUpper())
            {
                case "YES":
                    goto UserChoice;
                case "NO":
                    break;
                default:
                    Console.WriteLine("Incorrect Choice, please try again!");
                    goto AnotherCalculation;
            }
        }
    }
    class CalculatePerimeter
    {
        public double result1;
        public virtual void Perimeter(double LengthOfSide)
        {
        }
        public virtual void Perimeter(double Height, double Width)
        {
        }
        public void ShowResult()
        {
            Console.WriteLine($"Your Result for Perimeter is {result1}\n");

        }
    }
    class CalculateArea
    {
        public double result;
        public virtual void Area(double LengthOfSide)
        { 
        }
        public virtual void Area(double Height, double Width)
        {
        }
        public void ShowResult()
        {
            Console.WriteLine($"Your Result for Area is {result}\n");
        }
    }
    class Square: CalculateArea 
    {
        public override void Area(double LengthOfSide)
        {
            result = LengthOfSide * LengthOfSide;
        }
    }
    class Rectangle: CalculateArea
    {
        public override void Area(double Height, double Width)
        {
            result = Height * Width;
        }
    }
    class Circle : CalculateArea
    {
        public override void Area(double Radius)
        {
            result = 3.14159 * Radius * Radius;
        }
    }
    class Ellipse : CalculateArea
    {
        public override void Area(double SemiMajorAxis, double SemiMinorAxis)
        {
            result = 3.14159 *SemiMajorAxis * SemiMinorAxis ;
        }
    }
    class Squar : CalculatePerimeter
    {
        public override void Perimeter(double LengthOfSide)
        {
            result1 = 4 * LengthOfSide;
        }
    }
    class Rectangl : CalculatePerimeter
    {
        public override void Perimeter(double Height, double Width)
        {
            result1 = 2 * Height + 2 * Width;
        }
    }
    class Circl : CalculatePerimeter
    {
        public override void Perimeter(double Radius)
        {
            result1 = 2 * 3.14159 * Radius;
        }
    }
    class Ellips : CalculatePerimeter
    {
        public override void Perimeter(double SemiMajorAxis, double SemiMinorAxis)
        {
            result1 = 2 * 3.14159 * Math.Sqrt(( Math.Pow(SemiMajorAxis,2) +Math.Pow(SemiMinorAxis,2))/2);
        }
    }
}
